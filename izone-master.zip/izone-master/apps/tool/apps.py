from django.apps import AppConfig


class ToolConfig(AppConfig):
    name = 'tool'
